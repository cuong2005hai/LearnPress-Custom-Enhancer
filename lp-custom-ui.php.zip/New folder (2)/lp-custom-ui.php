<?php
/*
Plugin Name: LP Custom UI DINH HUU CUONG
Description: Custom giao diện LearnPress (Notification + Course Info + Style)
Version: 1.0
Author: DINH HUU CUONG
*/

// ===============================
// 1. Notification Bar
// ===============================
add_action('wp_body_open', function () {

    if (!is_singular('lp_course')) return;

    echo '<div class="lp-notify-bar">';

    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        echo 'Chào <strong>' . esc_html($user->display_name) . '</strong>, bạn đã sẵn sàng bắt đầu bài học hôm nay chưa?';
    } else {
        echo '<a href="' . esc_url(wp_login_url()) . '">Đăng nhập để lưu tiến độ học tập!</a>';
    }

    echo '</div>';
});


// ===============================
// 2. Shortcode [lp_course_info]
// ===============================
add_shortcode('lp_course_info', function ($atts) {

    if (!function_exists('learn_press_get_course')) {
        return '<p>LearnPress chưa kích hoạt</p>';
    }

    $atts = shortcode_atts([
        'id' => get_the_ID(),
    ], $atts);

    $course_id = intval($atts['id']);
    $course = learn_press_get_course($course_id);

    if (!$course) return 'Không có khóa học';

    // Lessons
    $lessons = $course->get_items('lp_lesson');
    $lesson_count = is_array($lessons) ? count($lessons) : 0;

    // Duration
    $duration = method_exists($course, 'get_duration') ? $course->get_duration() : '';

    // User status
    $status = 'Chưa đăng ký';
    $status_class = 'not-enrolled';

    if (is_user_logged_in()) {
        $user = learn_press_get_user(get_current_user_id());

        if ($user->has_finished_course($course_id)) {
            $status = 'Đã hoàn thành';
            $status_class = 'finished';

        } elseif ($user->has_enrolled_course($course_id)) {
            $status = 'Đang học';
            $status_class = 'learning';
        }
    }

    ob_start();
    ?>

    <div class="lp-course-box">
        <h3>Thông tin khóa học</h3>

        <ul>
            <li><strong>Số bài học:</strong> <?php echo esc_html($lesson_count); ?></li>
            <li><strong>Thời lượng:</strong> <?php echo esc_html($duration); ?></li>
            <li><strong>Trạng thái:</strong> 
                <span class="status <?php echo $status_class; ?>">
                    <?php echo esc_html($status); ?>
                </span>
            </li>
        </ul>

        <div class="lp-actions">
            <button class="btn-enroll">Ghi danh ngay</button>
            <button class="btn-finish">Hoàn thành khóa học</button>
        </div>
    </div>

    <?php
    return ob_get_clean();
});


// ===============================
// 3. CSS tự động
// ===============================
add_action('wp_head', function () {
?>
<style>

/* Notification */
.lp-notify-bar {
    position: fixed;
    top: 0;
    width: 100%;
    background: #222;
    color: #fff;
    text-align: center;
    padding: 12px;
    z-index: 9999;
    font-size: 14px;
}

/* Box */
.lp-course-box {
    border-radius: 12px;
    padding: 20px;
    background: #fff;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    max-width: 350px;
}

.lp-course-box h3 {
    margin-bottom: 15px;
}

/* List */
.lp-course-box ul {
    list-style: none;
    padding: 0;
}

.lp-course-box li {
    margin-bottom: 10px;
}

/* Status */
.status {
    font-weight: bold;
}

.status.finished {
    color: #28a745;
}

.status.learning {
    color: #ff8c00;
}

.status.not-enrolled {
    color: #999;
}

/* Buttons */
.lp-actions {
    margin-top: 15px;
}

.lp-actions button {
    width: 100%;
    border: none;
    padding: 12px;
    border-radius: 8px;
    font-weight: bold;
    margin-bottom: 10px;
    cursor: pointer;
}

/* Enroll - Cam */
.btn-enroll {
    background: #ff6b00;
    color: #fff;
}

/* Finish - Xanh lá */
.btn-finish {
    background: #28a745;
    color: #fff;
}

/* Hover */
.btn-enroll:hover {
    background: #e65c00;
}

.btn-finish:hover {
    background: #218838;
}

</style>
<?php
});